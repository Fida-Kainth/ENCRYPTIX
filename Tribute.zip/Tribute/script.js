window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('hero').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
  }, 4000); 
});
