import Job from '../models/Job.js';

export const createJob = async (req, res) => {
  const job = await Job.create({ ...req.body, postedBy: req.user.id });
  res.status(201).json(job);
};

export const getJobs = async (req, res) => {
  const jobs = await Job.find();
  res.json(jobs);
};

export const getJobById = async (req, res) => {
  const job = await Job.findById(req.params.id);
  res.json(job);
};
