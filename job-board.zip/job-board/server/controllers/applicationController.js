import Application from '../models/Application.js';

export const applyJob = async (req, res) => {
  const { jobId } = req.body;
  const resumePath = req.file?.path;

  const application = await Application.create({
    candidate: req.user.id,
    job: jobId,
    resume: resumePath
  });

  res.status(201).json(application);
};

export const getApplications = async (req, res) => {
  const apps = await Application.find({ candidate: req.user.id }).populate('job');
  res.json(apps);
};
