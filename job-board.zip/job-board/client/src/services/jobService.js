import api from './api';

export const getAllJobs = async () => {
  const res = await api.get('/jobs');
  return res.data;
};
