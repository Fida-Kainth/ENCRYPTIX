import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home/Home';
import Jobs from './pages/Jobs/Jobs';
import JobDetail from './pages/JobDetail/JobDetail';
import Login from './pages/Login/Login';
import Register from './pages/Register/Register';
import CandidateDashboard from './pages/CandidateDashboard/CandidateDashboard';
import EmployerDashboard from './pages/EmployerDashboard/EmployerDashboard';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/jobs" element={<Jobs />} />
      <Route path="/jobs/:id" element={<JobDetail />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
      <Route path="/employer/dashboard" element={<EmployerDashboard />} />
    </Routes>
  );
}
