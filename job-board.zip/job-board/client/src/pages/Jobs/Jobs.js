import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';

const Jobs = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await api.get('/jobs');
        setJobs(res.data);
      } catch (err) {
        console.error('Failed to fetch jobs:', err);
      }
    };
    fetchJobs();
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Job Listings</h2>

      {jobs.length === 0 ? (
        <p className="text-gray-600">No jobs found.</p>
      ) : (
        jobs.map((job) => (
          <div key={job._id} className="bg-white p-4 rounded shadow mb-4">
            <Link to={`/jobs/${job._id}`}>
              <h3 className="text-xl font-semibold text-blue-600 hover:underline">
                {job.title}
              </h3>
            </Link>
            <p className="text-gray-700">{job.company} – {job.location}</p>
            <p className="text-sm text-gray-500">{job.type}</p>
            <p className="mt-2 text-gray-700">{job.description?.slice(0, 100)}...</p>
          </div>
        ))
      )}
    </div>
  );
};

export default Jobs;
