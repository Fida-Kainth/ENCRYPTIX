import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAllJobs } from '../../services/jobService';
import './Home.css';

const Home = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const data = await getAllJobs();
        setJobs(data);
      } catch (error) {
        console.error('Failed to fetch jobs:', error);
      }
    };

    fetchJobs();
  }, []);

  return (
    <div className="home-container">
      <h1 className="welcome-heading">🌟 Welcome to the Job Board 🌟</h1>

      {jobs.length > 0 ? (
        <div className="job-grid">
          {jobs.map((job) => (
            <div key={job._id} className="job-card">
              <Link to={`/jobs/${job._id}`}>
                <h2 className="job-title">{job.title}</h2>
              </Link>
              <p className="job-info"><strong>Company:</strong> {job.company}</p>
              <p className="job-info"><strong>Location:</strong> {job.location}</p>
              <p className="job-info"><strong>Type:</strong> {job.type}</p>
              <p className="job-description">
                {job.description?.slice(0, 100)}...
              </p>
              <div className="view-details">
                <Link to={`/jobs/${job._id}`} className="details-button">
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="no-jobs-message">No jobs available right now.</p>
      )}
    </div>
  );
};

export default Home;
