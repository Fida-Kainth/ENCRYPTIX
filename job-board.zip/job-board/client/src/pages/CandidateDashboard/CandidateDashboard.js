import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import './CandidateDashboard.css';

const CandidateDashboard = () => {
  const [resume, setResume] = useState(null);
  const [appliedJobs, setAppliedJobs] = useState([]);

  // Fetch applied jobs on mount
  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const res = await api.get('/candidate/applications');
        setAppliedJobs(res.data);
      } catch (err) {
        console.error('Failed to fetch applications:', err);
      }
    };
    fetchApplications();
  }, []);

  // Handle resume file input
  const handleFileChange = e => {
    setResume(e.target.files[0]);
  };

  // Handle resume upload submission
  const handleUpload = async e => {
    e.preventDefault();
    if (!resume) return;

    const formData = new FormData();
    formData.append('resume', resume);

    try {
      await api.post('/candidate/upload-resume', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert('Resume uploaded successfully!');
      setResume(null);
    } catch (err) {
      console.error('Failed to upload resume:', err);
    }
  };

  return (
    <div className="candidate-container">
      <h2>Candidate Dashboard</h2>

      <form className="upload-form" onSubmit={handleUpload}>
        <label>
          Upload Resume (PDF only):
          <input type="file" accept=".pdf" onChange={handleFileChange} />
        </label>
        <button type="submit">Upload</button>
      </form>

      <h3>Applied Jobs</h3>
      <ul className="applied-jobs">
        {appliedJobs.length > 0 ? (
          appliedJobs.map(job => (
            <li key={job._id}>
              <strong>{job.title}</strong> at {job.company} – {job.location}
            </li>
          ))
        ) : (
          <p>No job applications yet.</p>
        )}
      </ul>
    </div>
  );
};

export default CandidateDashboard;
