import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../../services/api';
import './JobDetails.css'; // Correct relative path to CSS

const JobDetail = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);

  useEffect(() => {
    const fetchJob = async () => {
      try {
        const res = await api.get(`/jobs/${id}`);
        setJob(res.data);
      } catch (err) {
        console.error('Error fetching job:', err);
      }
    };
    fetchJob();
  }, [id]);

  if (!job) {
    return <div className="job-detail loading">Loading job details...</div>;
  }

  return (
    <div className="job-detail">
      <h1>{job.title}</h1>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p><strong>Type:</strong> {job.type}</p>
      <p><strong>Description:</strong></p>
      <div className="job-description">{job.description}</div>
    </div>
  );
};

export default JobDetail;
