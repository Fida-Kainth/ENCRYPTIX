import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import './EmployerDashboard.css';

const EmployerDashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    company: '',
    location: '',
    type: '',
    description: '',
  });

  // Fetch employer's jobs on component mount
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await api.get('/employer/jobs');
        setJobs(res.data);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      }
    };
    fetchJobs();
  }, []);

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  
  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const res = await api.post('/employer/post-job', formData);
      setJobs(prev => [...prev, res.data]);
      setFormData({ title: '', company: '', location: '', type: '', description: '' });
      setShowForm(false);
    } catch (error) {
      console.error('Failed to post job:', error);
    }
  };

  return (
    <div className="dashboard-container">
      <h2>Employer Dashboard</h2>

      <button className="post-job-btn" onClick={() => setShowForm(!showForm)}>
        {showForm ? 'Cancel' : 'Post New Job'}
      </button>

      {showForm && (
        <form className="job-form" onSubmit={handleSubmit}>
          <input name="title" placeholder="Job Title" value={formData.title} onChange={handleChange} required />
          <input name="company" placeholder="Company Name" value={formData.company} onChange={handleChange} required />
          <input name="location" placeholder="Location" value={formData.location} onChange={handleChange} required />
          <input name="type" placeholder="Job Type" value={formData.type} onChange={handleChange} required />
          <textarea name="description" placeholder="Description" value={formData.description} onChange={handleChange} required />
          <button type="submit">Submit Job</button>
        </form>
      )}

      <h3>Your Posted Jobs:</h3>
      <ul className="job-list">
        {jobs.map(job => (
          <li key={job._id}>
            <strong>{job.title}</strong> – {job.location} ({job.type})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EmployerDashboard;
