import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home/Home';
import JobDetail from './pages/JobDetail/JobDetail';
import CandidateDashboard from './pages/CandidateDashboard/CandidateDashboard';
import EmployerDashboard from './pages/EmployerDashboard/EmployerDashboard'; 


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/jobs/:id" element={<JobDetail />} />
        <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
        <Route path="/employer/dashboard" element={<EmployerDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
